# StormFN-Launcher
The Launcher used for StormFN. 

Launcher Made in C# ModernWpf

Make sure to give credit if you will use launcher or args

https://discord.gg/stormfn

# Creators

Stormzy Glitches and NOTPIES
